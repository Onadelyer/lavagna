<!DOCTYPE html>
<html>
<head>
    <title>Sample PHP Page</title>
</head>
<body>
    <h1>Hello, World!</h1>
    <p>This is a sample PHP page deployed through AWS Elastic Beanstalk.</p>
</body>
</html>
